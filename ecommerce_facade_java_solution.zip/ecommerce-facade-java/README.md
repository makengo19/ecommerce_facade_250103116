# E-commerce Checkout — Facade Pattern (Java)

A demonstration of the **Facade design pattern**. The client calls a single method,
`CheckoutFacade.placeOrder(...)`, and the facade coordinates four subsystems behind the scenes.

## Structure

```
src/com/ecommerce/
├── CheckoutFacade.java       # Facade  – one entry point: placeOrder(...)
├── InventoryService.java     # Subsystem 1 – stock check, reserve, release (rollback)
├── PaymentGateway.java       # Subsystem 2 – charges the customer
├── ShippingService.java      # Subsystem 3 – schedules delivery, returns tracking number
├── NotificationService.java  # Subsystem 4 – sends the receipt
└── OrderController.java      # Client  – runs 3 demo scenarios
```

```
OrderController ──► CheckoutFacade ──┬──► InventoryService
   (client)          (facade)        ├──► PaymentGateway
                                     ├──► ShippingService
                                     └──► NotificationService
```

## Workflow inside `placeOrder`

1. Validate input data
2. `inventory.checkStock()` – abort if out of stock
3. `inventory.reserve()` – reserve the item
4. `payment.charge()` – if declined → `inventory.release()` (**rollback**) and abort
5. `shipping.scheduleDelivery()` – returns a tracking number
6. `notification.sendReceipt()` – receipt includes the tracking number

## What was completed / improved

| Class | Change |
|-------|--------|
| `InventoryService` | Real in-memory stock (`Map`), `checkStock` now depends on quantity; added `release()` |
| `PaymentGateway` | Decline scenario (amount <= 0 or > $5000) instead of always returning `true` |
| `ShippingService` | `scheduleDelivery` now generates and returns a tracking number |
| `NotificationService` | `sendReceipt` receives and prints the tracking number |
| `CheckoutFacade` | Input validation, **rollback** of the reservation when payment fails, extra constructor for dependency injection |
| `OrderController` | Three scenarios: success, out of stock, payment declined |

## Build and run

Requires JDK 8 or newer.

```bash
mkdir out
javac -d out src/com/ecommerce/*.java
java -cp out com.ecommerce.OrderController
```

## Expected result

| Scenario | Product | Amount | Result |
|----------|---------|--------|--------|
| 1. Success | `Laptop-X1` | $1200 | Order completed |
| 2. Out of stock | `Phone-Z2` | $800 | Order failed (no stock) |
| 3. Payment declined | `Laptop-X1` | $9999 | Order failed, reservation rolled back (stock returns to its previous value) |
