package com.ecommerce;

/**
 * The Facade Class: CheckoutFacade
 * Coordinates the underlying subsystems (Inventory, Payment, Shipping, Notification)
 * behind a unified, single-method interface for callers.
 */
public class CheckoutFacade {

    // Subsystem instances maintained by the Facade
    private final InventoryService inventory;
    private final PaymentGateway payment;
    private final ShippingService shipping;
    private final NotificationService notification;

    /**
     * Step 1: Initialize all internal subsystem dependencies (default wiring).
     */
    public CheckoutFacade() {
        this(new InventoryService(), new PaymentGateway(), new ShippingService(), new NotificationService());
    }

    /**
     * Step 1 (alternative): Dependency-injection constructor.
     * Allows supplying custom/mock subsystems, e.g. for unit testing.
     */
    public CheckoutFacade(InventoryService inventory, PaymentGateway payment,
                          ShippingService shipping, NotificationService notification) {
        this.inventory = inventory;
        this.payment = payment;
        this.shipping = shipping;
        this.notification = notification;
    }

    /**
     * Step 2: Unified checkout orchestrator.
     * Coordinates the full multi-service workflow in the proper sequence.
     *
     * @param productId Identifier of the purchased item.
     * @param customerId Identifier of the purchasing user.
     * @param address Physical delivery destination.
     * @param amount Total transaction charge.
     * @return true if the entire checkout workflow succeeded, false otherwise.
     */
    public boolean placeOrder(String productId, String customerId, String address, double amount) {
        System.out.println("=== [CheckoutFacade] Starting Order Placement Workflow ===");

        // Step 2.0: Validate input data
        if (productId == null || customerId == null || address == null || amount <= 0) {
            System.out.println("[CheckoutFacade] Aborting: Invalid order data.");
            return false;
        }

        // Step 2.1: Verify warehouse inventory availability
        if (!inventory.checkStock(productId)) {
            System.out.println("[CheckoutFacade] Aborting: Item out of stock.");
            return false;
        }

        // Step 2.2: Reserve the item in stock
        inventory.reserve(productId);

        // Step 2.3: Process billing and charge customer
        if (!payment.charge(customerId, amount)) {
            // Step 2.3.1: Rollback - give the reserved item back to stock
            inventory.release(productId);
            System.out.println("[CheckoutFacade] Aborting: Payment declined. Reservation rolled back.");
            return false;
        }

        // Step 2.4: Schedule logistics carrier dispatch
        String trackingNumber = shipping.scheduleDelivery(productId, address);

        // Step 2.5: Dispatch digital receipt confirmation
        notification.sendReceipt(customerId, amount, trackingNumber);

        System.out.println("=== [CheckoutFacade] Order Workflow Completed Successfully ===");
        return true;
    }
}
