package com.ecommerce;

import java.util.HashMap;
import java.util.Map;

/**
 * Subsystem Class 1: InventoryService
 * Responsible for verifying and allocating product inventory.
 */
public class InventoryService {

    // In-memory warehouse: productId -> available quantity
    private final Map<String, Integer> stock = new HashMap<>();

    /**
     * Initialize the warehouse with demo data.
     */
    public InventoryService() {
        stock.put("Laptop-X1", 5);
        stock.put("Phone-Z2", 0); // intentionally out of stock (used in the out-of-stock scenario)
    }

    /**
     * Step 1: Check whether sufficient stock is available in the warehouse.
     *
     * @param productId The unique identifier of the item.
     * @return true if item is in stock and available for order, false otherwise.
     */
    public boolean checkStock(String productId) {
        // Step 1.1: Query warehouse database/inventory cache
        System.out.println("[InventoryService] Step 1: Checking stock levels for item: " + productId);

        // Step 1.2: Return stock status (unknown products are treated as out of stock)
        return stock.getOrDefault(productId, 0) > 0;
    }

    /**
     * Step 2: Reserve the requested stock so subsequent concurrent orders do not oversell.
     *
     * @param productId The unique identifier of the item.
     */
    public void reserve(String productId) {
        // Step 2.1: Lock and decrement available stock count
        stock.computeIfPresent(productId, (id, qty) -> qty - 1);
        System.out.println("[InventoryService] Step 2: Stock reserved successfully for item: " + productId
                + " (remaining: " + stock.getOrDefault(productId, 0) + ")");
    }

    /**
     * Step 3 (compensation): Release a previously reserved item back to stock.
     * Called by the facade when a later step (e.g. payment) fails.
     *
     * @param productId The unique identifier of the item.
     */
    public void release(String productId) {
        // Step 3.1: Increment available stock count
        stock.merge(productId, 1, Integer::sum);
        System.out.println("[InventoryService] Step 3: Reservation released for item: " + productId
                + " (remaining: " + stock.get(productId) + ")");
    }
}
