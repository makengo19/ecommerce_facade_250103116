package com.ecommerce;

/**
 * Client Class: OrderController
 * Demonstrates how client code interacts with the subsystem via the Facade.
 */
public class OrderController {

    public static void main(String[] args) {
        // Step 1: Create a single instance of the Facade
        CheckoutFacade checkout = new CheckoutFacade();

        // Step 2: Run three scenarios through the same one-method facade interface
        runScenario(checkout, "Scenario 1: Successful order",
                "Laptop-X1", "user_404", "123 Main St", 1200.00);

        runScenario(checkout, "Scenario 2: Out of stock",
                "Phone-Z2", "user_404", "123 Main St", 800.00);

        runScenario(checkout, "Scenario 3: Payment declined (stock is rolled back)",
                "Laptop-X1", "user_404", "123 Main St", 9999.00);
    }

    private static void runScenario(CheckoutFacade checkout, String title,
                                    String item, String customer, String address, double price) {
        System.out.println("\n------------------------------------------------------");
        System.out.println(title);
        System.out.println("------------------------------------------------------");

        // Step 3: Call the simplified one-method facade interface
        System.out.println("Client initiating checkout via Facade...");
        boolean success = checkout.placeOrder(item, customer, address, price);

        // Step 4: Handle high-level outcome
        if (success) {
            System.out.println("Client received: Order completed successfully!");
        } else {
            System.out.println("Client received: Order failed.");
        }
    }
}
