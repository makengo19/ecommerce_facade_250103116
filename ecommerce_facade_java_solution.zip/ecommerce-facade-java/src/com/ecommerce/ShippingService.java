package com.ecommerce;

/**
 * Subsystem Class 3: ShippingService
 * Responsible for logistics, carrier dispatch, and scheduling order delivery.
 */
public class ShippingService {

    /**
     * Step 1: Schedule the delivery assignment with a logistics carrier.
     *
     * @param productId The item to be shipped.
     * @param address The shipping destination address.
     * @return the generated tracking number of the shipment.
     */
    public String scheduleDelivery(String productId, String address) {
        // Step 1.1: Validate shipping address format
        System.out.println("[ShippingService] Step 1: Validating delivery destination: " + address);

        // Step 1.2: Register package with logistics courier and generate tracking number
        String trackingNumber = "TRK-" + System.currentTimeMillis();
        System.out.println("[ShippingService] Step 2: Delivery scheduled for item " + productId
                + " to address: " + address + " (tracking: " + trackingNumber + ")");

        return trackingNumber;
    }
}
